<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesmenu.css">
    <title>ForneInjet</title>
</head>

<body>
    <ul>
        <li><a href="login.php">Voltar para Login</a></li>

        <li class="dropdow">
            <a href="javascript:void(0)" class="dropbtn">Cadastrar</a>
            <div class="dropdown-content">
 
                <a href="inserirCliente.php">Cliente</a>
            
            </div>
        </li>

        <li class="dropdow">
            <a href="javascript:void(0)" class="dropbtn">Listar</a>
            <div class="dropdown-content">
 
                <a href="listarCliente.php">Cliente</a>

            </div>
        </li>

        <li class="dropdow">
            <a href="javascript:void(0)" class="dropbtn">Pesquisar</a>
            <div class="dropdown-content">
 
                <a href="pesquisarCliente.php">Cliente</a>

            </div>
        </li>

        <li class="dropdow">
            <a href="javascript:void(0)" class="dropbtn">Alterar</a>
            <div class="dropdown-content">

                <a href="atualizarCliente.php">Cliente</a>

            </div>
        </li>

        <li class="dropdow">
            <a href="javascript:void(0)" class="dropbtn">Excluir</a>
            <div class="dropdown-content">
 
                <a href="deletarCliente.php">Cliente</a>

            </div>
        </li>
    </ul>


    <h2></h2>
</body>

</html>